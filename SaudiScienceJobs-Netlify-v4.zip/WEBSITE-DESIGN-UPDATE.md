# Website design refresh

The public website now uses a light Arabic layout inspired by the supplied Saudi Dental Jobs screenshot: teal headings, locally hosted Noto Sans Arabic fonts, real vacancy/city/today counts, clickable city rows with proportional bars, search, specialty pills, city select, clear filters, rounded vacancy cards, and a quieter footer.

Saved jobs, block/unblock, report/remove links, employer sign-in/deletion, support/privacy links and the native mobile API remain available. Attribution remains هينار — @vlogqueenn. No sample jobs or fabricated statistics were added.

Deploy this source through the existing Netlify Next.js build workflow. Keep existing environment variables. It is not a static drag-and-drop export. This website update changes the browser UI; it does not require another iOS archive. The previously supplied native iOS build still uses /api/mobile/jobs.

Validation: production build, TypeScript, ESLint, 13 HTTP checks and mobile API contract checks passed. Responsive rules cover narrow mobile and desktop layouts. Browser screenshot/interaction validation was unavailable because the browser download timed out; verify the deployed page at 390px and desktop widths, city selection, search, saved filters and contact actions before release. No live deployment was performed here.

Font license: public/fonts/OFL.txt. Fonts are served from your own website.
