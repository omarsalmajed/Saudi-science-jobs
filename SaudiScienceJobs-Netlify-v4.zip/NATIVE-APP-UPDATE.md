# Native iOS feed update — build 2

Deploy this Next.js source through the existing Netlify build process before using the new iOS build. This ZIP is not a static Netlify Drop export. Existing environment variables remain required.

GET /api/mobile/jobs supplies the native iOS screens. It uses the same public published-job query and row-level access rules as the website, with an explicit field allowlist and no account identifiers. A JSON jobs array, including an empty array, means success. HTTP 503 means feed/database configuration is unavailable; HTTP 404 means this route has not been deployed. Errors do not expose backend details.

Verification: production build and lint passed; mobile API contract tests passed (field mapping, private-field exclusion, legacy publisher fallback, empty feed, error sanitization); 13 production HTTP checks passed, including mobile 503 JSON behavior without database configuration. Live data/authentication remain deployment checks.

Matching iOS project: SaudiScienceJobs-iOS-Project.zip, build 2; see START-HERE.md inside it for upload and device testing steps.
