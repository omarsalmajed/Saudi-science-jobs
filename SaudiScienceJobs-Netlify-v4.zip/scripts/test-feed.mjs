import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const source=readFileSync(new URL('../lib/feed-query.ts',import.meta.url),'utf8');
const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {queryPublishedFeed,FEED_COLUMNS}=await import('data:text/javascript;base64,'+Buffer.from(js).toString('base64'));
const cutoff='2026-08-19T00:00:00Z';
function mock(replies){const calls=[];return {calls,client:{from(table){assert.equal(table,'jobs');return {select(columns){const call={columns,filters:[]};calls.push(call);const chain={eq(...v){call.filters.push(['eq',...v]);return chain},gte(...v){call.filters.push(['gte',...v]);return chain},order(...v){call.order=v;return chain},limit(value){call.limit=value;assert(replies.length);return Promise.resolve(replies.shift())}};return chain}}}}};}
const modern={data:[{id:'modern',publisher_id:'publisher'}],error:null};
let m=mock([modern]);assert.deepEqual(await queryPublishedFeed(m.client,cutoff),modern);assert.equal(m.calls.length,1);
const old={data:[{id:'existing-job'}],error:null};
m=mock([{data:null,error:{code:'42703',message:'column jobs.publisher_id does not exist'}},old]);assert.deepEqual(await queryPublishedFeed(m.client,cutoff),old);assert.equal(m.calls.length,2);assert.equal(m.calls[1].columns,FEED_COLUMNS);
for(const call of m.calls){assert.deepEqual(call.filters,[['eq','status','published'],['gte','posted_at',cutoff]]);assert.equal(call.limit,500);assert.deepEqual(call.order,['posted_at',{ascending:false}]);assert(!call.columns.split(',').includes('owner_id'));}
for(const error of [{code:'42501',message:'permission denied'},{code:'NETWORK',message:'failed to fetch'},{code:'42703',message:'column jobs.other_field does not exist'}]){const result={data:null,error};m=mock([result]);assert.deepEqual(await queryPublishedFeed(m.client,cutoff),result);assert.equal(m.calls.length,1);}
const failed={data:null,error:{code:'42501',message:'permission denied'}};
m=mock([{data:null,error:{code:'42703',message:'column jobs.publisher_id does not exist'}},failed]);assert.deepEqual(await queryPublishedFeed(m.client,cutoff),failed);assert.equal(m.calls.length,2);
console.log('Feed regression checks passed: modern/legacy schemas, unchanged publication/expiry filters, no account IDs, no retry for unrelated errors, and fallback failure propagated.');
