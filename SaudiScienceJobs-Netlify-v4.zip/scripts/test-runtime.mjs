import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
const cwd=fileURLToPath(new URL('..',import.meta.url));
const server=spawn(process.execPath,[cwd+'/node_modules/next/dist/bin/next','start','-p','8090','-H','127.0.0.1'],{cwd,stdio:['ignore','pipe','pipe']});
(async()=>{
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Server startup timed out')),15000);server.stdout.on('data',data=>{if(data.toString().includes('Ready')){clearTimeout(timer);resolve();}});server.on('exit',()=>reject(new Error('Server exited')));});
 const base='http://127.0.0.1:8090';
 const mobile=await fetch(base+'/api/mobile/jobs');
 assert.equal(mobile.status,503);
 assert.deepEqual(await mobile.json(),{error:'feed_unavailable'});
 console.log('PASS /api/mobile/jobs 503 JSON');
 for(const path of ['/','/privacy.html','/support.html','/community.html','/account','/report?job=sample-job','/submit','/admin/reports','/auth/confirm']){
  const r=await fetch(base+path);assert.equal(r.status,200,path);const text=await r.text();
  if(['/submit','/auth/confirm'].includes(path))assert(r.url.includes('/account'));
  if(path==='/admin/reports')assert(r.url.includes('/admin'));
  if(path.startsWith('/report'))assert(text.includes('sample-job'));
  console.log('PASS '+path);
 }
 for(const [path,data,origin,status] of [['/api/report',{reason:'Removal',details:'Details'},false,403],['/api/report',{},true,400],['/api/submit',{},true,503]]){
  const r=await fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json',...(origin?{Origin:base}:{})},body:JSON.stringify(data)});assert.equal(r.status,status);console.log('PASS '+path+' '+status);
 }
})().then(()=>{server.kill();console.log('13 production HTTP checks passed');}).catch(e=>{server.kill();console.error(e);process.exitCode=1;});
