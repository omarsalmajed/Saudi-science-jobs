import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  icons: { icon: "/favicon.png", apple: "/apple-touch-icon.png" },
  title: "Saudi Science Jobs | وظائف العلوم السعودية",
  description: "أحدث وظائف العلوم في المملكة العربية السعودية، محدثة كل 30 دقيقة.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
