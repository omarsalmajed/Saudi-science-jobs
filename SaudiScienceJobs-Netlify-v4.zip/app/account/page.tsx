import BrandMark from "@/app/BrandMark";
import Link from "next/link";
import { sessionClient, configured } from "@/lib/supabase/server";
import { sendLink, signInWithPassword, logOut, deleteAccount } from "./actions";
export const dynamic = "force-dynamic";
export default async function Account({ searchParams }: { searchParams: Promise<{ mode?: string; message?: string }> }) {
  const { mode, message } = await searchParams;
  const posting = mode === "post";
  const user = configured ? (await (await sessionClient()).auth.getUser()).data.user : null;
  return <main className="innerPage">
    <header className="topbar"><Link className="brand" href="/"><BrandMark/><span>وظائف العلوم <small>Saudi Science Jobs</small></span></Link><nav><Link href="/">الوظائف</Link><a href="/support.html">الدعم</a></nav></header>
    <section className="pageHero"><h1>{posting ? "دخول أصحاب العمل" : "إدارة وحذف حساب المعلن"}</h1><p>تصفح الوظائف والبحث والحفظ متاح دون حساب.</p></section>
    <section className="formPanel">
      {message && <p role="status">{message}</p>}
      {!configured ? <p>خدمة الدخول غير مهيأة حالياً. يمكنك تصفح الوظائف دون حساب.</p> : !user ? <>
        <form action={signInWithPassword}>
          <input type="hidden" name="mode" value={posting ? "post" : "manage"}/>
          <div className="formGrid">
            <label className="wide">البريد الإلكتروني<input type="email" name="email" required autoComplete="email" maxLength={254}/></label>
            <label className="wide">كلمة المرور<input type="password" name="password" required autoComplete="current-password" minLength={8} maxLength={128}/></label>
          </div>
          {posting && <label className="rulesCheck"><input type="checkbox" name="acceptRules" value="yes" required/> أوافق على <a href="/community.html">قواعد النشر</a> و<a href="/privacy.html">الخصوصية</a>.</label>}
          <button className="primary">تسجيل الدخول</button>
        </form>
        <details>
          <summary>الدخول عبر رابط البريد</summary>
          <form action={sendLink}>
            <input type="hidden" name="mode" value={posting ? "post" : "manage"}/>
            <div className="formGrid"><label className="wide">بريد حساب المعلن<input type="email" name="email" required autoComplete="email" maxLength={254}/></label></div>
            {posting && <label className="rulesCheck"><input type="checkbox" name="acceptRules" value="yes" required/> أوافق على <a href="/community.html">قواعد النشر</a> و<a href="/privacy.html">الخصوصية</a>.</label>}
            <p>{posting ? "ينشأ حساب معلن عند الدخول لأول مرة. الإعلانات تُراجع قبل النشر." : "استخدم بريد حساب موجود؛ إدارة الحساب لا تنشئ حساباً جديداً."}</p>
            <button className="primary">إرسال رابط الدخول</button>
          </form>
        </details>
      </> : <>
        <p>الحساب: <bdi>{user.email}</bdi></p>
        <p><Link href="/submit">إرسال وظيفة للمراجعة</Link></p>
        <form action={logOut}><button className="primary">تسجيل الخروج</button></form>
        <details className="deleteAccount"><summary>حذف الحساب نهائياً</summary>
          <p>سيُحذف حساب الدخول وملف المعلن وجميع الإعلانات المرتبطة به، بما فيها قيد المراجعة. لا يمكن التراجع. الإعلانات المستوردة من مصادر عامة لا ترتبط بهذا الحساب ويمكن طلب إزالتها من صفحة البلاغات.</p>
          <form action={deleteAccount}><div className="formGrid"><label className="wide">اكتب بريد الحساب لتأكيد الحذف<input type="email" name="confirmEmail" required autoComplete="off"/></label></div>
            <label className="rulesCheck"><input name="confirmDelete" type="checkbox" value="yes" required/> أفهم أن الحذف نهائي.</label>
            <button className="primary danger">تأكيد الحذف النهائي</button>
          </form>
        </details>
      </>}
      <p><a href="/privacy.html">الخصوصية</a> · <a href="/community.html">قواعد النشر</a> · <Link href="/">العودة للوظائف دون تسجيل</Link></p>
    </section>
  </main>;
}
