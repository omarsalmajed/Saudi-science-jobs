"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { sessionClient, serviceClient, configured } from "@/lib/supabase/server";

function back(message: string, mode = "manage"): never {
  redirect(`/account?${new URLSearchParams({ mode, message })}`);
}
export async function sendLink(form: FormData) {
  const mode = form.get("mode") === "post" ? "post" : "manage";
  const email = String(form.get("email") ?? "").trim();
  if (!configured) back("خدمة الدخول غير مهيأة بعد.", mode);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) back("أدخل بريداً صحيحاً.", mode);
  if (mode === "post" && form.get("acceptRules") !== "yes") back("وافق على قواعد النشر والخصوصية أولاً.", mode);
  const site = process.env.SITE_URL;
  if (!site || new URL(site).protocol !== "https:") back("خدمة الدخول غير مهيأة بعد.", mode);
  const sb = await sessionClient();
  const { error } = await sb.auth.signInWithOtp({ email, options: {
    shouldCreateUser: mode === "post",
    emailRedirectTo: new URL(`/auth/confirm?next=${mode === "post" ? "/submit" : "/account"}`, site).href,
  } });
  // Do not reveal whether an account exists in manage-only mode.
  if (error && mode === "post") back("تعذر إرسال الرابط. انتظر قليلاً وتحقق من البريد ثم حاول مجدداً.", mode);
  back("إذا كان البريد صالحاً للحساب، ستصلك رسالة دخول. استخدم أحدث رسالة وتحقق من البريد غير المرغوب.", mode);
}
export async function signInWithPassword(form: FormData) {
  const mode = form.get("mode") === "post" ? "post" : "manage";
  const email = String(form.get("email") ?? "").trim();
  const password = String(form.get("password") ?? "");
  if (!configured) back("خدمة الدخول غير مهيأة بعد.", mode);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || password.length < 8 || password.length > 128) {
    back("تحقق من البريد وكلمة المرور.", mode);
  }
  if (mode === "post" && form.get("acceptRules") !== "yes") back("وافق على قواعد النشر والخصوصية أولاً.", mode);
  const sb = await sessionClient();
  let { error } = await sb.auth.signInWithPassword({ email, password });

  // App Review needs durable credentials that do not depend on an inbox.
  // Provision (or repair) this restricted advertiser account only when the
  // exact published review credentials are supplied. It receives no admin
  // role and submitted vacancies still enter the normal moderation queue.
  const reviewEmail = "app@saudisciencejobs.com";
  const reviewPassword = "Science1";
  if (error && email.toLowerCase() === reviewEmail && password === reviewPassword && process.env.SUPABASE_SERVICE_KEY) {
    const service = serviceClient();
    const listed = await service.auth.admin.listUsers({ page: 1, perPage: 1000 });
    const existing = listed.data.users.find((candidate) => candidate.email?.toLowerCase() === reviewEmail);
    const provisioned = existing
      ? await service.auth.admin.updateUserById(existing.id, { password: reviewPassword, email_confirm: true })
      : await service.auth.admin.createUser({ email: reviewEmail, password: reviewPassword, email_confirm: true });
    if (!provisioned.error) ({ error } = await sb.auth.signInWithPassword({ email: reviewEmail, password: reviewPassword }));
  }
  if (error) back("البريد أو كلمة المرور غير صحيحة.", mode);
  revalidatePath("/account");
  redirect(mode === "post" ? "/submit" : "/account?message=" + encodeURIComponent("تم تسجيل الدخول."));
}
export async function logOut() {
  const sb = await sessionClient();
  const { error } = await sb.auth.signOut({ scope: "local" });
  if (error) back("تعذر تسجيل الخروج.");
  revalidatePath("/account"); back("تم تسجيل الخروج.");
}
export async function deleteAccount(form: FormData) {
  const sb = await sessionClient();
  const { data: { user }, error } = await sb.auth.getUser();
  if (error || !user?.email) back("سجل الدخول إلى حسابك أولاً.");
  const confirmed = String(form.get("confirmEmail") ?? "").trim().toLowerCase();
  if (confirmed !== user.email.toLowerCase() || form.get("confirmDelete") !== "yes") back("أكد الحذف واكتب بريد الحساب نفسه.");
  const age = Date.now() - new Date(user.last_sign_in_at ?? 0).getTime();
  if (!Number.isFinite(age) || age < 0 || age > 10 * 60 * 1000) back("لحماية حسابك، سجل الخروج ثم افتح رابط دخول جديداً قبل الحذف.");
  if (!process.env.SUPABASE_SERVICE_KEY) back("خدمة الحذف غير مهيأة. لم يتم حذف الحساب.");
  const service = serviceClient();
  // Accounts with administrative privileges need an admin handover, not automatic deletion.
  const { data: admin, error: adminError } = await service.from("admins").select("email").ilike("email", user.email).limit(1);
  if (adminError) back("تعذر التحقق من الحساب. لم يتم تأكيد الحذف.");
  if (admin?.length) back("هذا حساب إدارة. تواصل مع الدعم لنقل صلاحيات الإدارة قبل حذف الحساب.");
  const schema = await service.from("advertisers").select("user_id").eq("user_id", user.id).limit(1);
  if (schema.error) back("خدمة الحذف غير مهيأة. لم يتم حذف الحساب.");
  const { data: session } = await sb.auth.getSession();
  if (!session.session) back("أعد تسجيل الدخول.");
  const revoked = await service.auth.admin.signOut(session.session.access_token, "global");
  if (revoked.error) back("تعذر تأمين حذف الحساب. لم يتم تأكيد الحذف.");
  // The required database FK deletes owned jobs and advertiser profile in this same transaction.
  const deletion = await service.auth.admin.deleteUser(user.id, false);
  if (deletion.error) back("تعذر حذف الحساب. لم يتم تأكيد الحذف. أعد الدخول وحاول مجدداً.");
  await sb.auth.signOut({ scope: "local" });
  revalidatePath("/");
  back("تم حذف الحساب وإعلاناته المرتبطة نهائياً.");
}
