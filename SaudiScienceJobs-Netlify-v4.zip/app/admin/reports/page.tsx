import Link from "next/link";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { currentAdmin } from "../actions";
import { sessionClient, configured } from "@/lib/supabase/server";
export const dynamic = "force-dynamic";
async function moderate(form: FormData) {
  "use server";
  if (!(await currentAdmin())?.isAdmin) throw new Error("غير مصرح");
  const sb = await sessionClient();
  const id = String(form.get("id") ?? "");
  const report = await sb.from("reports").select("job_id").eq("id", id).single();
  if (report.error) throw new Error("تعذر تحميل البلاغ");
  const jobId = report.data.job_id;
  const action = String(form.get("action"));
  if (jobId && action === "remove") {
    const result = await sb.from("jobs").update({ status: "deleted" }).eq("id", jobId);
    if (result.error) throw new Error("تعذر إزالة الإعلان");
  }
  if (jobId && action === "suspend") {
    const job = await sb.from("jobs").select("publisher_id").eq("id", jobId).single();
    if (job.error || !job.data.publisher_id) throw new Error("لا يوجد حساب معلن مرتبط بهذا الإعلان. استخدم إزالة الإعلان.");
    const result = await sb.rpc("suspend_advertiser", { publisher: job.data.publisher_id });
    if (result.error) throw new Error("تعذر إيقاف المعلن");
  }
  const result = await sb.from("reports").update({ status: "resolved" }).eq("id", id);
  if (result.error) throw new Error("تعذر تحديث البلاغ");
  revalidatePath("/"); revalidatePath("/admin/reports");
}
export default async function Reports() {
  if (!configured || !(await currentAdmin())?.isAdmin) redirect("/admin");
  const sb = await sessionClient();
  const { data, error } = await sb.from("reports").select("id,job_id,reason,details,contact,created_at").eq("status", "pending").order("created_at");
  return <main className="adminWrap"><Link href="/admin">لوحة الإدارة</Link><h1>البلاغات وطلبات الإزالة</h1>
    {error && <p role="alert">تعذر تحميل البلاغات. تحقق من إعداد قاعدة البيانات.</p>}
    {!error && !data?.length && <p>لا توجد بلاغات معلقة.</p>}
    {data?.map(report => <article className="adminPanel" key={report.id}>
      <h2>{report.reason}</h2><p style={{ whiteSpace: "pre-wrap" }}>{report.details}</p><p>{report.contact ?? "دون وسيلة رد"}</p><p>الإعلان: {report.job_id ?? "غير محدد"}</p>
      <form action={moderate}><input type="hidden" name="id" value={report.id}/><button className="primary" name="action" value="resolve">تمت المراجعة</button>
        {report.job_id && <><button className="primary" name="action" value="remove">إزالة الإعلان</button><button className="primary danger" name="action" value="suspend">إيقاف حساب المعلن وإزالة إعلاناته</button></>}
      </form>
    </article>)}
  </main>;
}
