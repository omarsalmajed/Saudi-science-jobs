import { requestOrigin } from "@/lib/request-origin";
import { NextResponse } from "next/server";
import { serviceClient } from "@/lib/supabase/server";
const hits = new Map<string, number[]>();
export async function POST(req: Request) {
  if (req.headers.get("origin") !== requestOrigin(req)) return NextResponse.json({ error: "طلب غير صالح." }, { status: 403 });
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "unknown";
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter(t => now - t < 3600000);
  if (recent.length >= 5) return NextResponse.json({ error: "طلبات كثيرة. حاول لاحقاً." }, { status: 429 });
  recent.push(now); if (hits.size > 5000) hits.clear(); hits.set(ip, recent);
  try {
    const raw = await req.json();
    if (raw.website) return NextResponse.json({ ok: true });
    const reason = typeof raw.reason === "string" ? raw.reason.trim().slice(0, 100) : "";
    const details = typeof raw.details === "string" ? raw.details.trim().slice(0, 2000) : "";
    const contact = typeof raw.contact === "string" ? raw.contact.trim().slice(0, 254) : "";
    const jobId = typeof raw.job_id === "string" ? raw.job_id.trim().slice(0, 200) : "";
    if (!reason || !details) return NextResponse.json({ error: "اكتب السبب والتفاصيل." }, { status: 400 });
    const service = serviceClient();
    if (jobId) {
      const job = await service.from("jobs").select("id").eq("id", jobId).maybeSingle();
      if (job.error || !job.data) return NextResponse.json({ error: "لم نعثر على الإعلان. اذكر تفاصيله دون معرّف أو تواصل مع الدعم." }, { status: 400 });
    }
    const result = await service.from("reports").insert({ job_id: jobId || null, reason, details, contact: contact || null });
    if (result.error) throw result.error;
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "تعذر حفظ البلاغ. حاول لاحقاً أو تواصل مع الدعم." }, { status: 503 }); }
}
