import { NextResponse } from "next/server";
import { fetchPublishedJobs } from "@/lib/jobs";

export const dynamic = "force-dynamic";
export const revalidate = 0;

// Same public/RLS-filtered feed as the website. No account IDs or private data.
export async function GET() {
  try {
    const { jobs, error } = await fetchPublishedJobs();
    if (error) return NextResponse.json({ error: "feed_unavailable" }, { status: 503 });
    return NextResponse.json({ jobs: jobs.map(j => ({
      id: j.id, title: j.title ?? "شاغر علمي", employer: j.employer ?? "جهة غير مسماة",
      specialty: j.specialty ?? "علوم عامة", city: j.city ?? "غير محددة",
      district: j.district, employmentType: j.employment_type, compensation: j.compensation,
      notes: j.notes, genderPreference: j.gender_pref, saudiOnly: j.saudi_only,
      needsSCFHS: j.needs_scfhs, postedAt: j.posted_at,
      phone: j.contact_phone, email: j.contact_email, applyURL: j.apply_url,
      sourceURL: j.permalink, publisherKey: j.publisher_key ?? `job:${j.id}`,
    })) }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ error: "feed_unavailable" }, { status: 503 });
  }
}
