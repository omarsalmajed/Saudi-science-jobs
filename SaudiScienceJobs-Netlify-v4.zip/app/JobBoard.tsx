"use client";
import BrandMark from "@/app/BrandMark";

/* Public browsing plus on-device saved jobs and publisher blocking. */

import { useMemo, useState } from "react";
import Link from "next/link";
import { useDevicePreferences } from "@/lib/device-preferences";
import { arabicDate, contactTarget, SPECIALTIES, type Job } from "@/lib/job-shared";

const specialties = ["الكل", ...SPECIALTIES];

/** The card's grey line: whatever the ad actually stated, nothing invented. */
function detailLine(job: Job): string {
  const bits: string[] = [];
  if (job.compensation && job.compensation !== "غير مذكور") bits.push(job.compensation);
  if (job.saudi_only) bits.push("للسعوديين");
  if (job.needs_scfhs) bits.push("يتطلب تصنيف");
  if (job.gender_pref) bits.push(job.gender_pref);
  if (job.notes) bits.push(job.notes);
  return bits.join(" · ");
}

export default function JobBoard({ jobs, notice }: { jobs: Job[]; notice?: string | null }) {
  const [specialty, setSpecialty] = useState("الكل"),
    [city, setCity] = useState("الكل"),
    [query, setQuery] = useState(""),
    [revealed, setRevealed] = useState<string[]>([]);

  const { value: preferences, update } = useDevicePreferences();
  const [savedOnly, setSavedOnly] = useState(false);
  const [showBlocked, setShowBlocked] = useState(false);
  const [allCities, setAllCities] = useState(false);
  const keyFor = (job: Job) => job.publisher_key ?? `job:${job.id}`;
  function block(job: Job) {
    const key = keyFor(job);
    const label = job.employer ?? job.title ?? "معلن";
    const single = key.startsWith("job:");
    if (!window.confirm(single ? "لا توجد هوية معلن كافية. هل تريد إخفاء هذا الإعلان فقط؟" : `حظر ${label} وإخفاء إعلاناته على هذا الجهاز؟`)) return;
    update(p => ({ ...p, blocked: [...p.blocked.filter(b => b.key !== key), { key, label }] }));
  }
  const publicJobs = jobs.filter(j => !preferences.blocked.some(b => b.key === keyFor(j)));
  const cityCounts = Array.from(new Set(publicJobs.map(j => j.city ?? "غير محددة")))
    .map(name => ({ name, count: publicJobs.filter(j => (j.city ?? "غير محددة") === name).length }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, "ar"));
  const cities = ["الكل", ...cityCounts.map(c => c.name)];
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Riyadh" }).format(new Date());
  const newToday = publicJobs.filter(j => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Riyadh" }).format(new Date(j.posted_at)) === today).length;
  function chooseCity(name: string) {
    setCity(name); setSavedOnly(false);
    document.getElementById("jobs")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  // Only offer a specialty pill if something live actually matches it.
  const activeSpecialties = specialties.filter(
    s => s === "الكل" || jobs.some(j => j.specialty === s));

  const visible = useMemo(() => jobs.filter(j =>
    !preferences.blocked.some(b => b.key === (j.publisher_key ?? `job:${j.id}`)) &&
    (!savedOnly || preferences.saved.includes(j.id)) &&
    (specialty === "الكل" || j.specialty === specialty) &&
    (city === "الكل" || (j.city ?? "غير محددة") === city) &&
    (!query || `${j.title ?? ""} ${j.employer ?? ""} ${j.city ?? ""} ${j.specialty ?? ""} ${j.notes ?? ""}`
      .includes(query.trim()))), [jobs, specialty, city, query, preferences, savedOnly]);

  const grouped = Array.from(new Set(visible.map(j => j.city ?? "غير محددة")))
    .map(c => ({ city: c, jobs: visible.filter(j => (j.city ?? "غير محددة") === c) }));

  return <main dir="rtl" className="jobBoard">
    <header className="topbar"><a className="brand" href="#" aria-label="وظائف العلوم — الرئيسية"><BrandMark/><span><b>وظائف العلوم</b><small>السعودية</small></span></a><nav aria-label="القائمة الرئيسية"><a href="#jobs">الوظائف</a><a href="/support.html">الدعم</a><Link className="outline" href="/submit"><span className="plus" aria-hidden="true">+</span><span>أضف وظيفة</span></Link></nav></header>
    <section className="hero"><div className="heroInner"><p className="eyebrow">فرص علمية · في أنحاء المملكة</p><h1>خطوتك القادمة<br/><span>في عالم العلوم</span></h1><p className="lead">اكتشف وظائف العلوم في السعودية، من إعلانات جهات العمل والقنوات المتخصصة. اختر مدينتك وتخصصك، واعثر على الفرصة المناسبة لك.</p><div className="heroLinks"><a className="exploreButton" href="#jobs">استكشف الوظائف <span aria-hidden="true">←</span></a><a href="/submit">تبحث عن كفاءات؟ أضف وظيفة <span aria-hidden="true">↗</span></a></div><div className="heroStats" aria-label="إحصائيات الوظائف"><span><b>{notice ? "—" : publicJobs.length}</b> شاغرًا متاحًا</span><span><b>{notice ? "—" : cityCounts.filter(c => c.name !== "غير محددة").length}</b> مدينة</span><span><b>{notice ? "—" : newToday}</b> جديد اليوم</span></div></div></section>
    {notice && <div className="feedNotice" role="status">{notice} <button onClick={() => window.location.reload()}>إعادة المحاولة</button></div>}
    {!notice && cityCounts.length > 0 && <section className="cityOverview" aria-labelledby="cities-title"><div className="sectionHeading"><h2 id="cities-title">الفرص حسب المدينة</h2><p>اختر المدينة لعرض وظائفها</p></div><div className="cityRows">{(allCities ? cityCounts : cityCounts.slice(0, 6)).map(c => <button className={city === c.name ? "cityRow selected" : "cityRow"} key={c.name} onClick={() => chooseCity(c.name)} aria-pressed={city === c.name}><span className="cityName">{c.name}</span><span className="cityMeter" aria-hidden="true"><span style={{ width: `${Math.max(4, (c.count / cityCounts[0].count) * 100)}%` }}/></span><span className="cityCount">{c.count}<span className="sr-only"> وظيفة</span></span><span className="cityArrow" aria-hidden="true">←</span></button>)}</div>{cityCounts.length > 6 && <button className="moreCities" onClick={() => setAllCities(!allCities)} aria-expanded={allCities}>{allCities ? "عرض مدن أقل" : `عرض جميع المدن (${cityCounts.length})`}</button>}</section>}
    <section className="filters" id="jobs" aria-labelledby="jobs-title"><div className="sectionHeading"><div><p className="eyebrow">فرصتك تبدأ من هنا</p><h2 id="jobs-title">ابحث عن وظيفتك القادمة</h2></div></div><div className="search"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg><input aria-label="ابحث في الوظائف" placeholder="المسمى الوظيفي، جهة العمل، أو كلمة مفتاحية" value={query} onChange={e => setQuery(e.target.value)} />{query && <button onClick={() => setQuery("")} aria-label="مسح البحث">×</button>}</div><div className="filterBlock"><span className="filterLabel">التخصص</span><div className="pills">{activeSpecialties.map(s => <button key={s} aria-pressed={specialty === s} className={specialty === s ? "active" : ""} onClick={() => setSpecialty(s)}>{s}</button>)}</div></div><div className="citySelectRow"><label htmlFor="city-select">المدينة</label><select id="city-select" value={city} onChange={e => setCity(e.target.value)}>{cities.map(c => <option key={c} value={c}>{c === "الكل" ? "جميع المدن" : c}</option>)}</select>{(specialty !== "الكل" || city !== "الكل" || query || savedOnly) && <button className="resetFilters" onClick={() => { setCity("الكل"); setSpecialty("الكل"); setQuery(""); setSavedOnly(false); }}>مسح الفلاتر</button>}</div></section>
    <section className="ledger"><div className="reviewControls">
      <button onClick={() => setSavedOnly(!savedOnly)} aria-pressed={savedOnly}>{savedOnly ? "عرض جميع الوظائف" : "الوظائف المحفوظة"}</button>
      <button onClick={() => setShowBlocked(!showBlocked)} aria-expanded={showBlocked}>المعلنون المحظورون ({preferences.blocked.length})</button>
      <Link href="/account">إدارة وحذف حساب المعلن</Link><a href="/support.html">الدعم</a>
    </div>
    {showBlocked && <section className="blockedPanel"><h2>المعلنون المحظورون</h2><p>الحظر والحفظ على هذا الجهاز فقط. الحساب غير مطلوب. إعلانات المحظورين تُخفى حتى من قائمة المحفوظة.</p>
      {!preferences.blocked.length && <p>لا يوجد معلنون محظورون.</p>}
      {preferences.blocked.map(b => <div key={b.key}><span>{b.label}{b.key.startsWith("job:") ? " (إعلان واحد)" : ""}</span><button onClick={() => update(p => ({ ...p, blocked: p.blocked.filter(x => x.key !== b.key) }))}>إلغاء الحظر</button></div>)}
    </section>}
    <div className="ledgerHead"><div><span className="liveDot"></span> {savedOnly ? "وظائفك المحفوظة" : "الوظائف المتاحة"}</div><span role="status" aria-live="polite">{notice ? "—" : visible.length} نتيجة</span></div>{grouped.length ? grouped.map(group => <section className="cityGroup" key={group.city}><h2><span>{group.city}</span><em>{group.jobs.length}</em></h2><div className="cards">{group.jobs.map(job => {
      const target = contactTarget(job);
      const details = detailLine(job);
      return <article className="job" key={job.id}><div className="jobTop"><div><span className="category">{job.specialty ?? "علوم عامة"}</span><span className="fresh">{arabicDate(job.posted_at)}</span></div><span className="source">{job.source === "employer" ? "جهة عمل" : "تيليجرام"}</span></div><h3>{job.title ?? "شاغر علمي"}</h3><p className="employer">{job.employer ?? "جهة غير مسماة"}</p><div className="meta"><span>⌖ {job.city ?? "غير محددة"}{job.district ? ` · ${job.district}` : ""}</span><span>◷ {job.employment_type ?? "غير محدد"}</span></div><p className="details">{details}</p>{revealed.includes(job.id)
        ? (target
          ? <a className="contactLink" href={target.href} target="_blank" rel="noopener noreferrer">{target.label}</a>
          : <span className="contactLink">لا توجد وسيلة تواصل في الإعلان</span>)
        : <button className="reveal" onClick={() => setRevealed([...revealed, job.id])}>إظهار وسيلة التواصل</button>}
        <div className="jobActions">
          <button aria-pressed={preferences.saved.includes(job.id)} onClick={() => update(p => ({ ...p, saved: p.saved.includes(job.id) ? p.saved.filter(id => id !== job.id) : [...p.saved, job.id] }))}>{preferences.saved.includes(job.id) ? "إلغاء الحفظ" : "حفظ الوظيفة"}</button>
          <Link href={`/report?job=${encodeURIComponent(job.id)}`}>إبلاغ / طلب إزالة</Link>
          <button onClick={() => block(job)}>{keyFor(job).startsWith("job:") ? "إخفاء الإعلان" : "حظر المعلن"}</button>
        </div></article>;
    })}</div></section>) : <div className="empty"><h3>{notice ? "تعذر تحميل الوظائف" : savedOnly ? "لا توجد وظائف محفوظة مطابقة" : "لا توجد فرص مطابقة"}</h3><p>{notice ?? "جرّب تغيير المدينة أو التخصص، أو مسح كلمة البحث."}</p></div>}</section>
    <section className="about" id="about"><p className="eyebrow">كيف تعمل المنصة؟</p><h2>نبحث، نصنّف، وننشر</h2><div className="steps"><div><b>01</b><h3>متابعة مستمرة</h3><p>نجمع الفرص من القنوات المتخصصة وجهات العمل.</p></div><div><b>02</b><h3>تصنيف ذكي</h3><p>نستخرج الوظائف العلمية داخل السعودية فقط.</p></div><div><b>03</b><h3>محتوى متجدد</h3><p>تُخفى الوظيفة تلقائياً بعد مرور 30 يوماً.</p></div></div></section>
    <footer><div className="brand"><BrandMark/><span><b>وظائف العلوم</b><small>Saudi Science Jobs</small></span></div><p>منصة مستقلة لجمع الوظائف العلمية في المملكة العربية السعودية.</p><div className="footerEnd"><span>© 2026</span><a href="/privacy.html">سياسة الخصوصية</a><a href="/support.html">الدعم والمساعدة</a><a href="/community.html">قواعد النشر</a><Link href="/account">إدارة وحذف الحساب</Link><Link className="adminLink" href="/admin">دخول الإدارة</Link><small className="footerPrayer">لا تنسونا ووالدينا من دعائكم<br />هينار — <bdi dir="ltr">@vlogqueenn</bdi></small></div></footer>
  </main>;
}
