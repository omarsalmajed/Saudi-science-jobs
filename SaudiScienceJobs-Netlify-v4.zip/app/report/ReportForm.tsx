"use client";
import BrandMark from "@/app/BrandMark";
import { FormEvent, useState } from "react";
import Link from "next/link";
export default function ReportForm({ initialJob }: { initialJob: string }) {
  const [job, setJob] = useState(initialJob);
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (busy) return; setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/report", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(new FormData(e.currentTarget))) });
      const result = await response.json();
      if (!response.ok || !result.ok) throw new Error(result.error ?? "تعذر إرسال البلاغ.");
      setSent(true); setMessage("تم حفظ البلاغ للمراجعة. لا يعني ذلك إزالة الإعلان تلقائياً.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "تعذر الاتصال."); }
    finally { setBusy(false); }
  }
  return <main className="innerPage"><header className="topbar"><Link className="brand" href="/"><BrandMark/><span>وظائف العلوم<small>Saudi Science Jobs</small></span></Link><a href="/support.html">الدعم</a></header><section className="pageHero"><h1>بلاغ أو طلب إزالة</h1><p>يمكنك إرسال البلاغ دون حساب ودون وسيلة تواصل.</p></section><section className="formPanel">
    {message && <p role="status">{message}</p>}
    {!sent && <form onSubmit={submit}><div className="formGrid">
      <label className="wide">معرّف الإعلان، إن توفر<input name="job_id" value={job} onChange={e => setJob(e.target.value)} maxLength={200}/></label>
      <label className="wide">السبب<select name="reason" required><option>احتيال أو معلومات مضللة</option><option>إساءة أو محتوى غير مناسب</option><option>طلب إزالة بيانات شخصية</option><option>إعلان منتهي أو غير صحيح</option><option>دعم أو مشكلة أخرى</option></select></label>
      <label className="wide">التفاصيل<textarea name="details" required rows={5} maxLength={2000}/></label>
      <label className="wide">وسيلة الرد (اختيارية)<input name="contact" maxLength={254}/></label>
    </div><input name="website" tabIndex={-1} aria-hidden="true" className="honeypot"/><p>لا ترسل كلمة مرور أو رابط دخول أو معلومات حساسة. <a href="/privacy.html">سياسة الخصوصية</a></p><button className="primary" disabled={busy}>{busy ? "جارٍ الإرسال…" : "إرسال للمراجعة"}</button></form>}
    <p><Link href="/">العودة للوظائف</Link></p>
  </section></main>;
}
