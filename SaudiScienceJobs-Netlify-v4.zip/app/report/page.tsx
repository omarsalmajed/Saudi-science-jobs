import ReportForm from "./ReportForm";
export default async function Report({ searchParams }: { searchParams: Promise<{ job?: string }> }) {
  const { job } = await searchParams;
  return <ReportForm initialJob={(job ?? "").slice(0, 200)}/>;
}
