import { redirect } from "next/navigation";
import { sessionClient, configured } from "@/lib/supabase/server";
import SubmitForm from "./SubmitForm";
export const dynamic = "force-dynamic";
export default async function Submit() {
  if (!configured) redirect("/account?mode=post");
  const { data: { user } } = await (await sessionClient()).auth.getUser();
  if (!user) redirect("/account?mode=post");
  return <SubmitForm/>;
}
