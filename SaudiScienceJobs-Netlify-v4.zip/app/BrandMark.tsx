import Image from "next/image";
export default function BrandMark() {
  return <Image className="brandMark" src="/science-logo.png" alt="" width={44} height={44} unoptimized/>;
}
