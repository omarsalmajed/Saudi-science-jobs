import { requestOrigin } from "@/lib/request-origin";
import { NextRequest, NextResponse } from "next/server";
import { sessionClient, configured } from "@/lib/supabase/server";
export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const destination = url.searchParams.get("next") === "/submit" ? "/submit" : "/account";
  if (!configured) return NextResponse.redirect(new URL("/account?message=" + encodeURIComponent("خدمة الدخول غير مهيأة حالياً."), requestOrigin(request)));
  const sb = await sessionClient();
  const hash = url.searchParams.get("token_hash");
  const code = url.searchParams.get("code");
  // Token-hash links also work when email opens in a different browser from the app.
  const result = hash ? await sb.auth.verifyOtp({ token_hash: hash, type: "email" })
    : code ? await sb.auth.exchangeCodeForSession(code) : null;
  const target = new URL(result && !result.error ? destination : "/account?message=" + encodeURIComponent("رابط الدخول غير صالح أو منتهي. اطلب رابطاً جديداً."), requestOrigin(request));
  const response = NextResponse.redirect(target);
  response.headers.set("Cache-Control", "no-store");
  response.headers.set("Referrer-Policy", "no-referrer");
  return response;
}
