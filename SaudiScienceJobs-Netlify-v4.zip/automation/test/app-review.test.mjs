import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const db = new PGlite();
let count = 0;
const pass = name => { count++; console.log('PASS ' + name); };
await db.exec(`create role anon nologin; create role authenticated nologin; create role service_role nologin bypassrls; create schema auth; create table auth.users(id uuid primary key,email text); create function auth.jwt() returns jsonb language sql stable as $$select coalesce(nullif(current_setting('request.jwt.claims',true),'')::jsonb,'{}'::jsonb)$$; create function auth.uid() returns uuid language sql stable as $$select (auth.jwt()->>'sub')::uuid$$; grant usage on schema auth to anon,authenticated,service_role;`);
await db.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
const setup = readFileSync(new URL('../app-review-setup.sql', import.meta.url), 'utf8');
await db.exec(setup); pass('Setup applies to original schema');
await db.exec(setup); pass('Setup can be reapplied');
const owner = '10000000-0000-0000-0000-000000000001', admin = '10000000-0000-0000-0000-000000000002', pub = '20000000-0000-0000-0000-000000000001';
await db.query('insert into auth.users(id,email) values ($1,$2),($3,$4)', [owner,'owner@example.com',admin,'admin@example.com']);
await db.exec("insert into public.admins(email) values ('admin@example.com')");
await db.query('insert into public.advertisers(user_id,public_id) values ($1,$2)', [owner,pub]);
await db.query("insert into public.jobs(id,status,source,owner_id,publisher_id) values ('owned','published','employer',$1,$2)", [owner,pub]);
await db.exec("insert into public.jobs(id,status,source) values ('imported','published','telegram'); insert into public.reports(job_id,reason,details) values ('owned','Removal','Private report')");
async function role(name, claims, fn) {
  await db.exec('begin'); await db.exec('set local role ' + name);
  await db.query("select set_config('request.jwt.claims',$1,true)", [JSON.stringify(claims)]);
  try { return await fn(); } finally { await db.exec('rollback'); }
}
async function denied(name, fn) { await assert.rejects(fn); pass(name); }
await role('anon', {}, async () => { assert.equal((await db.query('select id from public.jobs')).rows.length, 2); pass('Guest browsing remains available'); });
await denied('Guest cannot read account IDs', () => role('anon', {}, () => db.query('select owner_id from public.jobs')));
await denied('Signed-in visitor cannot read account IDs', () => role('authenticated', {email:'owner@example.com',sub:owner}, () => db.query('select owner_id from public.jobs')));
await denied('Guest cannot insert jobs directly', () => role('anon', {}, () => db.exec("insert into public.jobs(id) values ('attack')")));
await denied('Guest cannot read reports', () => role('anon', {}, () => db.query('select * from public.reports')));
await denied('Guest cannot suspend publishers', () => role('anon', {}, () => db.query('select public.suspend_advertiser($1)', [pub])));
await denied('Non-admin cannot suspend publishers', () => role('authenticated', {email:'owner@example.com',sub:owner}, () => db.query('select public.suspend_advertiser($1)', [pub])));
await role('authenticated', {email:'owner@example.com',sub:owner}, async () => {
  assert.equal((await db.query('select * from public.reports')).rows.length, 0); pass('Reports hidden from non-admins');
  assert.equal((await db.query('select * from public.advertisers')).rows.length, 0); pass('Advertisers hidden from non-admins');
});
await role('authenticated', {email:'admin@example.com',sub:admin}, async () => {
  assert.equal((await db.query('select * from public.reports')).rows.length, 1); pass('Admin can access queue');
  await db.query('select public.suspend_advertiser($1)', [pub]);
  assert.equal((await db.query("select status from public.jobs where id='owned'")).rows[0].status, 'deleted'); pass('Suspension removes owned jobs atomically');
});
await db.query('update public.advertisers set suspended=true where user_id=$1', [owner]);
await db.exec("update public.jobs set status='deleted' where id='owned'");
await denied('Suspended advertiser cannot submit', () => db.query("insert into public.jobs(id,status,owner_id) values ('another','pending',$1)", [owner]));
await denied('Suspended advertiser cannot be republished', () => db.exec("update public.jobs set status='published' where id='owned'"));
await db.query('delete from auth.users where id=$1', [owner]);
assert.equal((await db.query("select id from public.jobs where id='owned'")).rows.length, 0); pass('Deletion permanently removes owned jobs');
assert.equal((await db.query('select * from public.advertisers')).rows.length, 0); pass('Deletion removes advertiser profile');
assert.equal((await db.query("select id from public.jobs where id='imported'")).rows.length, 1); pass('Deletion preserves unrelated imports');
assert.equal((await db.query('select job_id from public.reports')).rows[0].job_id, null); pass('Report retains moderation record without deleted reference');
console.log(`${count} database checks passed`); await db.close();
