-- Apply AFTER automation/schema.sql. Run in Supabase SQL Editor.
-- No credentials are included. Existing jobs are not assigned guessed owners.
begin;
create table if not exists public.advertisers (
 user_id uuid primary key references auth.users(id) on delete cascade,
 public_id uuid not null unique default gen_random_uuid(),
 suspended boolean not null default false
);
alter table public.advertisers enable row level security;
drop policy if exists "admins manage advertisers" on public.advertisers;
create policy "admins manage advertisers" on public.advertisers for all to authenticated
 using (public.is_admin()) with check (public.is_admin());
revoke all on public.advertisers from anon, authenticated;
grant select,update on public.advertisers to authenticated;
grant all on public.advertisers to service_role;
alter table public.jobs add column if not exists owner_id uuid references auth.users(id) on delete cascade;
alter table public.jobs add column if not exists publisher_id uuid;
-- Column privileges keep auth user IDs out of public feeds (including authenticated visitors).
revoke select on public.jobs from public, anon, authenticated;
grant select (id,status,source,source_channel,post_id,permalink,relay_link,posted_at,created_at,updated_at,employer,title,specialty,city,district,employment_type,compensation,gender_pref,saudi_only,needs_scfhs,notes,contact_phone,contact_email,apply_url,from_image,ai_confidence,raw_excerpt,reviewed_by,reviewed_at,dedup_url,dedup_contact,dedup_fingerprint,publisher_id) on public.jobs to anon, authenticated;
create table if not exists public.reports (
 id uuid primary key default gen_random_uuid(),
 job_id text references public.jobs(id) on delete set null,
 reason text not null, details text not null, contact text,
 status text not null default 'pending' check (status in ('pending','resolved')),
 created_at timestamptz not null default now()
);
alter table public.reports enable row level security;
drop policy if exists "admins manage reports" on public.reports;
create policy "admins manage reports" on public.reports for all to authenticated
 using (public.is_admin()) with check (public.is_admin());
revoke all on public.reports from anon, authenticated;
grant select,update on public.reports to authenticated;
grant all on public.reports to service_role;
-- Unexposed trigger function prevents suspended publishers from being republished.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
create or replace function private.check_advertiser() returns trigger
language plpgsql security definer set search_path = '' as $$
declare stopped boolean;
begin
 if new.owner_id is not null then
   select suspended into stopped from public.advertisers where user_id = new.owner_id for share;
   if stopped is null then raise exception 'advertiser not found'; end if;
   if stopped and new.status in ('published','pending') then raise exception 'advertiser suspended'; end if;
 end if;
 return new;
end $$;
revoke all on function private.check_advertiser() from public, anon, authenticated;
drop trigger if exists jobs_check_advertiser on public.jobs;
create trigger jobs_check_advertiser before insert or update on public.jobs
 for each row execute function private.check_advertiser();
-- Callable by signed-in admins only; update and removal happen atomically.
create or replace function public.suspend_advertiser(publisher uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare target uuid;
begin
 if auth.uid() is null or not public.is_admin() then raise exception 'unauthorized'; end if;
 select user_id into target from public.advertisers where public_id = publisher for update;
 if target is null then raise exception 'advertiser not found'; end if;
 update public.advertisers set suspended = true where user_id = target;
 update public.jobs set status = 'deleted' where owner_id = target;
end $$;
revoke all on function public.suspend_advertiser(uuid) from public, anon, authenticated;
grant execute on function public.suspend_advertiser(uuid) to authenticated;
commit;
