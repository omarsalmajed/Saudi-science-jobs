# Saudi Science Jobs — App Store website updates

This package preserves the existing Science Jobs layout, attribution and import automation. The ZIP now has the project files at its root, with `netlify.toml` and pinned dependency lockfiles.

## Deploy the full website

This is Next.js source with server routes, authentication and administration, not a static Netlify Drop bundle. Do not drag it into a manual static deployment or publish only `public`: that would omit the job board/server routes. Extract it, replace the files in the existing website repository, and let the connected Netlify site build it. Use the repository root as Base directory, `npm run build` as Build command and `.next` as Publish directory. Netlify's Next.js adapter handles the server routes. This package has not been published.

Official guide: https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/

## Required backend setup

1. In the Saudi Science Jobs Supabase project (not the Dental Jobs project), apply `automation/schema.sql` if not already installed, followed by `automation/app-review-setup.sql` using SQL Editor. The latter adds advertiser ownership, publisher suspension and private reports. It can be reapplied. Existing jobs are kept and are not assigned guessed owners.
2. Keep the existing site credentials in Netlify: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_KEY`. Add `SITE_URL=https://saudisciencejobs.com`. The service key must stay server-only.
3. In Supabase Auth URL Configuration, set Site URL to `https://saudisciencejobs.com` and allow `https://saudisciencejobs.com/auth/confirm` redirects (including the query variants used by the site). Configure email delivery/SMTP for production. Do not reuse the Dental Jobs database or credentials.
4. Change the Magic Link email template to include this link:

```html
<h2>Saudi Science Jobs</h2>
<p><a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&amp;type=email">Sign in / تسجيل الدخول</a></p>
```

The token-hash link supports email opening in another browser, avoiding reliance on a PKCE verifier stored in the original browser. The new browser will be signed in; complete posting or deletion there. After sign-in, the account page links to submission. The callback also accepts PKCE `code` links for the same-browser case. Expired/invalid links return to sign-in with an error.

Official guide: https://supabase.com/docs/guides/auth/auth-email-passwordless

## Included flows and pages

- Account-free browsing, filtering, saving, blocking and unblocking.
- `/account?mode=post`: optional advertiser sign-in/new-account creation after accepting rules. `/submit`: authenticated submission for moderation, also enforced server-side.
- `/account`: existing-account sign-in (does not create a new account), sign-out and permanent deletion after confirming the account email. A sign-in within 10 minutes is required for deletion. Sessions are revoked before account deletion; database foreign keys remove the advertiser profile and linked vacancies in the account-deletion transaction. Deletion is unavailable if backend setup is missing. Administrative accounts require a support/admin handover before deletion.
- `/report?job=...`: private reports/removal requests, with optional reply contact and no required account. Invalid requests and missing database configuration show failures instead of false success.
- `/admin/reports`: moderation queue, removal and suspension of linked advertiser accounts. Suspension removes their listings atomically and prevents submission/republishing while suspended. Imported public-source advertisers without a linked account can be removed as listings; local blocking groups them by available contact identity.
- Cards: Save job, Report/request removal, Block publisher; Blocked publishers panel with Unblock. Without a contact or publisher identity, the control hides only the individual listing. Saved listings and blocks persist locally, including guest sessions; expired/removed listings are no longer available in Saved.
- `/privacy.html`, `/support.html`, `/community.html`: Arabic/English privacy, support and posting rules, linked from the footer. Operator and public contact: هينار — `@vlogqueenn`. The site also links to its support/report form at `/report`.

The iOS native saved-job notebook created separately does not synchronize with the website's saved list. This website package does not change Xcode/iPad screenshot settings or supply an App Store device recording.

## Verification and remaining live checks

Passed: production Next.js build, TypeScript, ESLint and 19 PostgreSQL/PGlite checks for guest access, report privacy, account-ID privacy, admin permissions, publisher suspension and cascading account/content deletion. Browser QA results are recorded in `VERIFICATION.md`.

The production database/website have not been changed. Before App Store submission, deploy this package and test actual email delivery/login, authenticated submission, guest reports arriving in the admin queue, removal/suspension, and permanent deletion of a disposable advertiser account with a vacancy. Record the actual iPhone build and use screenshots from each supported device. Policy URLs become usable for App Store Connect only after deployment. Confirm hosting/logging/retention settings match the supplied privacy policy and App Privacy answers. These checks do not establish App Store acceptance.

Run database checks locally: `cd automation`, `npm ci`, `npm run test:app-review`.

## Existing databases and missing jobs

The public feed can now read an existing jobs table before publisher_id is added. This compatibility retry does not enable the new account/report backend: apply the SQL setup for those. Missing site environment variables still prevent reading the feed and must be configured in Netlify. If there are no results, clear saved-only/search/city/specialty filters and local blocks, then check the displayed database error and deployment logs. Feed regression tests: `npm run test:feed`.
