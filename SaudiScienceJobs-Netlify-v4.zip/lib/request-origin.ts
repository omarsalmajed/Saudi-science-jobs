/** Use the configured public origin behind Netlify/Next.js proxies. */
export function requestOrigin(request: Request): string {
  if (process.env.SITE_URL) return new URL(process.env.SITE_URL).origin;
  const url = new URL(request.url);
  const host = request.headers.get("host");
  if (host) url.host = host;
  return url.origin;
}
