import type { SupabaseClient } from "@supabase/supabase-js";

// Read only public vacancy fields. Advertiser account IDs never belong here.
export const FEED_COLUMNS = "id,status,source,source_channel,post_id,permalink,relay_link,posted_at,employer,title,specialty,city,district,employment_type,compensation,gender_pref,saudi_only,needs_scfhs,notes,contact_phone,contact_email,apply_url,from_image,ai_confidence";
export async function queryPublishedFeed(client: SupabaseClient, cutoff: string) {
  const query = (columns: string) => client.from("jobs").select(columns)
    .eq("status", "published").gte("posted_at", cutoff)
    .order("posted_at", { ascending: false }).limit(500);
  const current = await query(FEED_COLUMNS + ",publisher_id");
  // Existing databases need not stop serving vacancies while the new setup is pending.
  // Retry only this known schema mismatch, never authentication/RLS/network errors.
  if (current.error?.code === "42703" && current.error.message.includes("publisher_id")) {
    return query(FEED_COLUMNS);
  }
  return current;
}
