import { createHash } from "node:crypto";
import type { Job } from "./job-shared";
export function publisherKey(job: Job): string {
  if (job.publisher_id) return `publisher:${job.publisher_id}`;
  const contact = job.contact_phone?.replace(/\D/g, "") || job.contact_email?.trim().toLowerCase();
  // Jobs without publisher identity can only be hidden individually.
  return contact ? "contact:" + createHash("sha256").update(contact).digest("hex") : `job:${job.id}`;
}
