"use client";
import { useMemo, useSyncExternalStore } from "react";
export type BlockedPublisher = { key: string; label: string };
type Preferences = { saved: string[]; blocked: BlockedPublisher[] };
const storageKey = "saudi-science-jobs-preferences-v1";
const empty: Preferences = { saved: [], blocked: [] };
function snapshot() { try { return localStorage.getItem(storageKey) ?? ""; } catch { return ""; } }
function decode(raw: string): Preferences {
  try {
    const value = JSON.parse(raw);
    return {
      saved: Array.isArray(value.saved) ? value.saved.filter((x: unknown) => typeof x === "string") : [],
      blocked: Array.isArray(value.blocked) ? value.blocked.filter((x: unknown) => typeof x === "object" && x !== null && "key" in x && "label" in x && typeof x.key === "string" && typeof x.label === "string") : [],
    };
  } catch { return empty; }
}
function subscribe(listener: () => void) {
  window.addEventListener("storage", listener); window.addEventListener("ssj-preferences", listener);
  return () => { window.removeEventListener("storage", listener); window.removeEventListener("ssj-preferences", listener); };
}
export function useDevicePreferences() {
  const raw = useSyncExternalStore(subscribe, snapshot, () => "");
  const value = useMemo(() => decode(raw), [raw]);
  function update(change: (previous: Preferences) => Preferences) {
    try {
      localStorage.setItem(storageKey, JSON.stringify(change(decode(snapshot()))));
      window.dispatchEvent(new Event("ssj-preferences"));
    } catch { window.alert("تعذر حفظ الاختيار على هذا الجهاز. تحقق من إعدادات التخزين."); }
  }
  return { value, update };
}
